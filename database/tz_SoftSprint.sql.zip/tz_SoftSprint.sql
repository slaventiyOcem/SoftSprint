-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:8889
-- Время создания: Дек 03 2023 г., 17:29
-- Версия сервера: 5.7.39
-- Версия PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `tz_SoftSprint`
--

-- --------------------------------------------------------

--
-- Структура таблицы `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_11_28_224458_create_products_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `photo_url`, `created_at`, `updated_at`) VALUES
(1, 'Балістичний шолом Sestan-Busch Helmet BK-ACH-HC. Койот. (S-XL)', '16800.00', 'Шолом Sestan BK-ACH-HC виготовлений в Хорватії із високоякісного арамідного волокна, що забезпечує захист голови від впливу вибухових хвиль, потрапляння пістолетних куль, рикошетів та захисту при ударяннях чи падіннях. Дане високоарамідне волокно - це довготривала праця Хорватських науковців, заявдяки яким даний шолом має найвищі балістичні властивості при мінімальній вазі.', '../img/image_test_1.jpg', NULL, NULL),
(2, 'Подсумок на пояс для пистолета', '715.00', 'Ношение пистолета открыто, на поясе либо под рукой в кобуре, как ни крути, вызывает опасение. Даже, если вы – сотрудник правоохранительных органов, спецслужб, в людных местах этого лучше не делать, чтобы не вызывать лишних вопросов. Поместите короткоствольное в  https://www.stall.com.ua/ru/product/9386/, и оно будет сокрыто от посторонних глаз. ', '../img/image_test_2.jpg', NULL, NULL),
(3, 'Фоторамка левітуюча з LED підсвічуванням', '2115.00', 'Фоторамка з підсвічуванням левітуюча додасть частинку магії і трохи чудес техніки в інтер\'єр житла. Пристрій відрізняється компактними габаритами і загадковим футуристичним дизайном. Корпус виконаний з міцного матеріалу, що робить цифрову фоторамку досить міцною. Гідна якість збірки, мається на увазі - тривалий термін експлуатації.\r\nКонструкція пристрою - чорний корпус химерної форми, всередині якого, в створюваному магнітному полі, наче повис в повітрі, плаває дисплей. Він відображає вкладені користувачем фотографії. Левітуюча фоторамка зі світлодіодним підсвічуванням вражаюче виглядає в темний час доби, створюючи романтичну атмосферу.\r\nТри причини того, чому літаюча фоторамка з led підсвічуванням - це те, що потрібно:\r\nнестандартне відображення фотографій;\r\nфутуристичний дизайн пристрою;\r\nвидовищне підсвічування світлодіодами.\r\nЛевітуюча рамка для фото буде оригінальним подарунком для друзів і колег, які перебувають в родинних стосунках.', '../img/image_test_3.jpg', NULL, NULL),
(4, 'Кружка Гра престолів RESTEQ з нержавіючої сталі. Чашка Game of Thrones', '1799.00', 'Кружка Гра престолів (Game of Thrones) RESTEQ на 600 мл!\r\nЗовнішня частина чашки виготовлена із синтетичної смоли, її не слід мити, а протирати злегка вологою тканиною.\r\nМатеріал: синтетична смола та нержавіюча сталь;\r\nВміщує близько 600 мл;\r\nРозміри: 10X14CM;\r\nВага: близько 800 р.', '../img/image_test_4.jpg', NULL, NULL),
(5, 'Зовнішня звукова карта USB 7.1 3D Адаптер (669931232) Чорний', '125.00', 'Зовнішня звукова карта USB 7.1 3D Адаптер (669931232) Чорний\r\nЗовнішня звукова карта знадобиться вам, якщо вбудована звукова карта ноутбука чи нетбука не працює, або якщо у вас немає або не працюють виходи на навушники та мікрофон.\r\nЗвукова карта має кнопки регулювання гучності. Також є кнопки для увімкнення/вимкнення звуку та мікрофона.\r\nЗвукова карта працює з усіма операційними системами, не потрібно нічого налаштовувати та встановлювати додаткові драйвери.\r\nUSB аудіо контролер із вбудованими двома каналами\r\nПідтримка 3D звуку Xear та віртуального 7.1-канального програвання\r\nUSB Plug & Play, драйверів не потрібно\r\nЖивлення від USB, зовнішнього живлення не потрібне\r\nЄ самостійним пристроєм, що не вимагає додаткової звукової карти\r\nКнопки: відключення звуку, відключення мікрофона, регулятор гучності\r\nРозміри: 57 х 25 х 12 мм', '../img/image_test_5.jpg', NULL, NULL),
(6, 'Набір бармена 26 предметів', '2492.00', 'Набір бармена із 750 мл. Шейкером є чудовий подарунок для любителів приготування коктейлів в домашніх умовах. Він включає необхідні інструменти та посібники для приготування різноманітних коктейлів, включаючи шейкер, мірну склянку, ложку для змішування та інші аксесуари. Цей набір може бути подарований на день народження, друзям, колегам або членам сім\'ї, які цікавляться барною культурою і бажають створювати смачні напої в домашніх умовах', '../img/image_test_6.jpg', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Индексы таблицы `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Индексы таблицы `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
